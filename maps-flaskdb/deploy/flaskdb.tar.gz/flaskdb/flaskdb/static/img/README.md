Uploaded files are stored into this directory. 
